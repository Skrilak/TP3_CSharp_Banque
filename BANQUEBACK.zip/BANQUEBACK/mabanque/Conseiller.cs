﻿
using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;

namespace BanqueBack
{
	public class Conseiller
	{
		private int id;
		private string nom;
		private string prenom;
		private string login;
		private string password;
        public List<Client> Clients { get; set; } = new List<Client>();

        public List<Client> GetClients()
        {
            return Clients;
        }
    }
}
