﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;


namespace BanqueBack
{

    class CompteEpargne : Compte
    {
        public string Type { get; set; }
        public double TauxInteret { get; set; }

        public decimal CalculerInteret()
        {
            return Solde * (decimal)TauxInteret;
        }
    }
}