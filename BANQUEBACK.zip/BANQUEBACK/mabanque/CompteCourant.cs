﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;

namespace BanqueBack
{
    class CompteCourant : Compte
    {
        public decimal DecouvertAutorise { get; set; }

        public override bool Retirer(decimal montant)
        {
            if (Solde - montant >= -DecouvertAutorise)
            {
                Solde -= montant;
                return true;
            }
            return false;
        }
    }
}
