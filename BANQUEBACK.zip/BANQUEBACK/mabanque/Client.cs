﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;

namespace BanqueBack
{
    public class Client
    {}
        private int id;
        private string nom;
        private string prenom;
        private string rue;
        private string codePostal;
        private string ville;
        private string mobil;
        private string mail;
        private List<Compte> comptes;

        public Client()
        {

        }
    }
}

