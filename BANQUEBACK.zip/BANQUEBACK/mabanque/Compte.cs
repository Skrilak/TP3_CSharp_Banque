﻿using System;
using System.Collections.Generic;

class Compte
{
    public int Id { get; set; }
    public decimal Solde { get; protected set; }

    public void Deposer(decimal montant)
    {
        Solde += montant;
    }

    public virtual bool Retirer(decimal montant)
    {
        if (Solde >= montant)
        {
            Solde -= montant;
            return true;
        }
        return false;
    }
}